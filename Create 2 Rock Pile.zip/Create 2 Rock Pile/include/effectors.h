void claw_open();
void claw_close_purp();
void move_servo_slow(int port, int end_pos, int step);